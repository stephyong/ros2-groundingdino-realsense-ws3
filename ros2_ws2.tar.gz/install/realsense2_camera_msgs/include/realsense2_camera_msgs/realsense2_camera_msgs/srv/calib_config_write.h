// generated from rosidl_generator_c/resource/idl.h.em
// with input from realsense2_camera_msgs:srv/CalibConfigWrite.idl
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__SRV__CALIB_CONFIG_WRITE_H_
#define REALSENSE2_CAMERA_MSGS__SRV__CALIB_CONFIG_WRITE_H_

#include "realsense2_camera_msgs/srv/detail/calib_config_write__struct.h"
#include "realsense2_camera_msgs/srv/detail/calib_config_write__functions.h"
#include "realsense2_camera_msgs/srv/detail/calib_config_write__type_support.h"

#endif  // REALSENSE2_CAMERA_MSGS__SRV__CALIB_CONFIG_WRITE_H_
