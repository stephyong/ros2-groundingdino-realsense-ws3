// generated from rosidl_generator_c/resource/idl.h.em
// with input from realsense2_camera_msgs:srv/CalibConfigRead.idl
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__SRV__CALIB_CONFIG_READ_H_
#define REALSENSE2_CAMERA_MSGS__SRV__CALIB_CONFIG_READ_H_

#include "realsense2_camera_msgs/srv/detail/calib_config_read__struct.h"
#include "realsense2_camera_msgs/srv/detail/calib_config_read__functions.h"
#include "realsense2_camera_msgs/srv/detail/calib_config_read__type_support.h"

#endif  // REALSENSE2_CAMERA_MSGS__SRV__CALIB_CONFIG_READ_H_
