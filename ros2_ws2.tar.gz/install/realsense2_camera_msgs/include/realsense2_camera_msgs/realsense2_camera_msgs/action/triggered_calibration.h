// generated from rosidl_generator_c/resource/idl.h.em
// with input from realsense2_camera_msgs:action/TriggeredCalibration.idl
// generated code does not contain a copyright notice

#ifndef REALSENSE2_CAMERA_MSGS__ACTION__TRIGGERED_CALIBRATION_H_
#define REALSENSE2_CAMERA_MSGS__ACTION__TRIGGERED_CALIBRATION_H_

#include "realsense2_camera_msgs/action/detail/triggered_calibration__struct.h"
#include "realsense2_camera_msgs/action/detail/triggered_calibration__functions.h"
#include "realsense2_camera_msgs/action/detail/triggered_calibration__type_support.h"

#endif  // REALSENSE2_CAMERA_MSGS__ACTION__TRIGGERED_CALIBRATION_H_
