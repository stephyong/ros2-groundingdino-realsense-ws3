import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from GroundingDINO.groundingdino.util.inference import load_model, predict
# ... (other imports as needed)

class DinoDetector(Node):
    def __init__(self):
        super().__init__('grounding_dino_node')
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image,
            '/camera/camera/color/image_raw',  # adjust as needed
            self.image_callback,
            10)
        self.publisher = self.create_publisher(Image, "/grounding_dino/annotated_image", 10)
        self.model = load_model("/home/sutd/ros2_ws2/src/GroundingDINO/groundingdino/config/GroundingDINO_SwinT_OGC.py",
    "/home/sutd/ros2_ws2/src/GroundingDINO/weights/groundingdino_swint_ogc.pth")
        self.declare_parameter("text_prompt", "blue circle") #blue circle is the default parameter value assigned to text prompt
        self.text_prompt = self.get_parameter("text_prompt").get_parameter_value().string_value
        #ros2 run your_package grounding_dino_node --ros-args -p text_prompt="cat"
        self.get_logger().info("Grounding Dino model loaded")

    def image_callback(self, msg):
        if msg is None or not hasattr(msg, 'data'):
            self.get_logger().warn('Received empty image message')
            return
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        # Convert BGR to RGB for Grounding DINO
        rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
        rgb_image.get_logger().info("rgb image done for grounding dino")


        # If Grounding DINO expects normalized float, convert as needed
        input_image = np.copy(rgb_image)  # Or preprocess as required
        input_image.get_logger().info("input image obtained")

        # Run prediction directly on NumPy arrays if possible
        # Assume predict(model, image, ...) can take np.array (adjust if needed)
        box_threshold = 0.35
        text_threshold = 0.25
        boxes, logits, phrases = predict(
            model=self.model,
            image=input_image,
            caption=self.text_prompt,
            box_threshold=box_threshold,
            text_threshold=text_threshold
        )
        
        # Optional: Draw results, publish annotated images, etc.
        # Call visualization functions here.
        for box, phrase in zip(boxes, phrases):
            x_min, y_min, x_max, y_max = map(int, box)
            cv2.rectangle(cv_image, (x_min, y_min), (x_max, y_max), (0,255,0), 2)
            cv2.putText(cv_image, phrase, (x_min, y_min-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        # Publish the result
        out_msg = self.bridge.cv2_to_imgmsg(cv_image, encoding="bgr8")
        out_msg.get_logger().info("cv image converted back to image")
        self.publisher.publish(out_msg)

def main(args=None):
    rclpy.init(args=args)
    node = DinoDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
