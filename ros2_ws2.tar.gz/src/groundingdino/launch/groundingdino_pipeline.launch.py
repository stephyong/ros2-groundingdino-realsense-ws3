from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # RealSense camera node (standard executable)
        Node(
            package='realsense2_camera',
            executable='realsense2_camera_node',  # standard executable for this driver
            name='camera_node',
            output='screen'
        ),
        # Grounding DINO detector node (your package)
        Node(
            package='groundingdino',
            executable='groundingdino',  # must match the name in entry_points/console_scripts
            name='grounding_dino_node',
            output='screen',
            parameters=[{'text_prompt': 'cat.dog'}],
            remappings=[
                ('/camera/camera/color/image_raw', '/camera/camera/color/image_raw'),  # add more as needed
                ('/grounding_dino/annotated_image', '/grounding_dino/annotated_image')
            ]
        )
    ])
